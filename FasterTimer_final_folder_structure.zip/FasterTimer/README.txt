FasterTimer Android build kit

Open the extracted FasterTimer folder as the project root.

Included layout:
- settings.gradle.kts
- build.gradle.kts
- gradle.properties
- app/src/main/assets/www/index.html
- app/src/main/java/com/fastertimer/MainActivity.kt
- app/src/main/res/...
- .github/workflows/build-apk.yml

The app loads locally from:
- app/src/main/assets/www/index.html

Build path:
- GitHub Actions builds a debug APK with Gradle installed by the workflow.
- The app uses an Android WebView wrapper and loads the HTML offline from assets.
