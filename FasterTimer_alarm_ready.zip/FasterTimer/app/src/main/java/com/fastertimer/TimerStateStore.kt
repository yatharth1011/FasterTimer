package com.fastertimer

import android.content.Context

object TimerStateStore {
    private const val PREFS = "fastertimer_timer_state"
    private const val KEY_APPARENT_MS = "apparent_ms"
    private const val KEY_REAL_MS = "real_ms"
    private const val KEY_STARTED_AT_WALL_MS = "started_at_wall_ms"
    private const val KEY_PAUSED_REAL_ELAPSED_MS = "paused_real_elapsed_ms"
    private const val KEY_PHASE = "phase"

    enum class Phase { IDLE, RUNNING, PAUSED, RINGING }

    data class State(
        val apparentMs: Long = 25 * 60 * 1000L,
        val realMs: Long = 25 * 60 * 1000L,
        val startedAtWallMs: Long = 0L,
        val pausedRealElapsedMs: Long = 0L,
        val phase: Phase = Phase.IDLE,
    ) {
        val scale: Double
            get() = if (realMs <= 0L) 1.0 else apparentMs.toDouble() / realMs.toDouble()

        fun realElapsedMs(nowWallMs: Long): Long = when (phase) {
            Phase.RUNNING -> pausedRealElapsedMs + (nowWallMs - startedAtWallMs).coerceAtLeast(0L)
            Phase.PAUSED, Phase.RINGING, Phase.IDLE -> pausedRealElapsedMs
        }

        fun remainingRealMs(nowWallMs: Long): Long = (realMs - realElapsedMs(nowWallMs)).coerceAtLeast(0L)

        fun remainingApparentMs(nowWallMs: Long): Long {
            val elapsed = realElapsedMs(nowWallMs).toDouble()
            return (apparentMs - elapsed * scale).toLong().coerceAtLeast(0L)
        }
    }

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun read(context: Context): State {
        val p = prefs(context)
        return State(
            apparentMs = p.getLong(KEY_APPARENT_MS, 25 * 60 * 1000L),
            realMs = p.getLong(KEY_REAL_MS, 25 * 60 * 1000L),
            startedAtWallMs = p.getLong(KEY_STARTED_AT_WALL_MS, 0L),
            pausedRealElapsedMs = p.getLong(KEY_PAUSED_REAL_ELAPSED_MS, 0L),
            phase = Phase.valueOf(p.getString(KEY_PHASE, Phase.IDLE.name) ?: Phase.IDLE.name)
        )
    }

    fun saveConfig(context: Context, apparentMs: Long, realMs: Long) {
        prefs(context).edit()
            .putLong(KEY_APPARENT_MS, apparentMs)
            .putLong(KEY_REAL_MS, realMs)
            .apply()
    }

    fun saveRunning(context: Context, startedAtWallMs: Long, pausedRealElapsedMs: Long = 0L) {
        prefs(context).edit()
            .putLong(KEY_STARTED_AT_WALL_MS, startedAtWallMs)
            .putLong(KEY_PAUSED_REAL_ELAPSED_MS, pausedRealElapsedMs)
            .putString(KEY_PHASE, Phase.RUNNING.name)
            .apply()
    }

    fun savePaused(context: Context, pausedRealElapsedMs: Long) {
        prefs(context).edit()
            .putLong(KEY_STARTED_AT_WALL_MS, 0L)
            .putLong(KEY_PAUSED_REAL_ELAPSED_MS, pausedRealElapsedMs)
            .putString(KEY_PHASE, Phase.PAUSED.name)
            .apply()
    }

    fun saveRinging(context: Context) {
        prefs(context).edit()
            .putString(KEY_PHASE, Phase.RINGING.name)
            .apply()
    }

    fun clear(context: Context) {
        prefs(context).edit()
            .putLong(KEY_STARTED_AT_WALL_MS, 0L)
            .putLong(KEY_PAUSED_REAL_ELAPSED_MS, 0L)
            .putString(KEY_PHASE, Phase.IDLE.name)
            .apply()
    }
}
