package com.fastertimer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlin.math.max

class TimerForegroundService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var mediaPlayer: MediaPlayer? = null
    private var tickRunnable: Runnable? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        ensureChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_TIMER -> {
                val apparentMs = intent.getLongExtra(EXTRA_APPARENT_MS, DEFAULT_MS)
                val realMs = intent.getLongExtra(EXTRA_REAL_MS, DEFAULT_MS)
                val pausedRealElapsed = intent.getLongExtra(EXTRA_PAUSED_REAL_ELAPSED_MS, 0L)
                val now = System.currentTimeMillis()
                TimerStateStore.saveConfig(this, apparentMs, realMs)
                TimerStateStore.saveRunning(this, now, pausedRealElapsed)
                startInRunningMode()
                scheduleAlarm(now, realMs - pausedRealElapsed)
            }
            ACTION_PAUSE_TIMER -> {
                val state = TimerStateStore.read(this)
                val now = System.currentTimeMillis()
                val elapsed = state.realElapsedMs(now)
                TimerAlarmScheduler.cancel(this)
                TimerStateStore.savePaused(this, elapsed)
                stopRingIfNeeded()
                updateNotification(paused = true)
            }
            ACTION_RESET_TIMER -> {
                TimerAlarmScheduler.cancel(this)
                stopRingIfNeeded()
                TimerStateStore.clear(this)
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            ACTION_TIMER_FIRED -> {
                startRingingMode()
            }
            ACTION_CONFIGURE_TIMER -> {
                val apparentMs = intent.getLongExtra(EXTRA_APPARENT_MS, DEFAULT_MS)
                val realMs = intent.getLongExtra(EXTRA_REAL_MS, DEFAULT_MS)
                TimerStateStore.saveConfig(this, apparentMs, realMs)
                updateNotification()
            }
            ACTION_TIMER_FINISHED -> {
                startRingingMode()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        stopRingIfNeeded()
        handler.removeCallbacksAndMessages(null)
    }

    private fun startInRunningMode() {
        startForeground(NOTIFICATION_ID, buildNotification(ringing = false).build())
        scheduleTicker()
    }

    private fun startRingingMode() {
        val state = TimerStateStore.read(this)
        TimerAlarmScheduler.cancel(this)
        TimerStateStore.saveRinging(this)
        startForeground(NOTIFICATION_ID, buildNotification(ringing = true).build())
        playAlarmSound()
        vibrateAlarm()
        stopTicker()
    }

    private fun scheduleAlarm(nowWallMs: Long, remainingRealMs: Long) {
        val triggerAt = nowWallMs + max(0L, remainingRealMs)
        TimerAlarmScheduler.schedule(this, triggerAt)
    }

    private fun scheduleTicker() {
        stopTicker()
        tickRunnable = object : Runnable {
            override fun run() {
                updateNotification()
                handler.postDelayed(this, 1000L)
            }
        }
        handler.post(tickRunnable!!)
    }

    private fun stopTicker() {
        tickRunnable?.let { handler.removeCallbacks(it) }
        tickRunnable = null
    }

    private fun updateNotification(paused: Boolean = false) {
        val state = TimerStateStore.read(this)
        val now = System.currentTimeMillis()
        val title = if (paused) "FasterTimer paused" else "FasterTimer running"
        val text = if (paused) {
            formatMs(state.remainingApparentMs(now)) + " remaining"
        } else {
            formatMs(state.remainingApparentMs(now)) + " left"
        }
        val notification = buildNotificationBase()
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .addAction(
                android.R.drawable.ic_media_play,
                if (paused) "Resume" else "Pause",
                servicePendingIntent(if (paused) ACTION_START_TIMER else ACTION_PAUSE_TIMER, state)
            )
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "Reset",
                servicePendingIntent(ACTION_RESET_TIMER, state)
            )
            .build()
        NotificationManagerCompat.from(this).notify(NOTIFICATION_ID, notification)
    }

    private fun buildNotification(ringing: Boolean): NotificationCompat.Builder {
        val state = TimerStateStore.read(this)
        val now = System.currentTimeMillis()
        val title = if (ringing) "Timer complete" else "FasterTimer running"
        val text = if (ringing) {
            "Tap to stop"
        } else {
            formatMs(state.remainingApparentMs(now)) + " left"
        }
        val builder = buildNotificationBase()
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setContentIntent(mainActivityPendingIntent())

        if (ringing) {
            builder.addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "Stop",
                servicePendingIntent(ACTION_RESET_TIMER, state)
            )
        } else {
            builder.addAction(
                android.R.drawable.ic_media_pause,
                "Pause",
                servicePendingIntent(ACTION_PAUSE_TIMER, state)
            )
            builder.addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "Reset",
                servicePendingIntent(ACTION_RESET_TIMER, state)
            )
        }
        return builder
    }

    private fun buildNotificationBase(): NotificationCompat.Builder {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setAutoCancel(false)
    }

    private fun mainActivityPendingIntent(): PendingIntent {
        return PendingIntent.getActivity(
            this,
            801,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun servicePendingIntent(action: String, state: TimerStateStore.State): PendingIntent {
        val serviceIntent = Intent(this, TimerForegroundService::class.java).apply {
            this.action = action
            putExtra(EXTRA_APPARENT_MS, state.apparentMs)
            putExtra(EXTRA_REAL_MS, state.realMs)
            putExtra(EXTRA_PAUSED_REAL_ELAPSED_MS, state.pausedRealElapsedMs)
        }
        return PendingIntent.getService(
            this,
            action.hashCode(),
            serviceIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "FasterTimer alarms",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Timer progress and alarm alerts"
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun playAlarmSound() {
        stopRingIfNeeded()
        val uri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: Settings.System.DEFAULT_ALARM_ALERT_URI
        try {
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(this@TimerForegroundService, uri)
                isLooping = true
                prepare()
                start()
            }
        } catch (_: Throwable) {
            mediaPlayer = null
        }
    }

    private fun vibrateAlarm() {
        val pattern = longArrayOf(0, 700, 300, 700, 300, 900)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = getSystemService(VibratorManager::class.java)
            vm?.defaultVibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
        } else {
            @Suppress("DEPRECATION")
            val vib = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            @Suppress("DEPRECATION")
            vib.vibrate(VibrationEffect.createWaveform(pattern, 0))
        }
    }

    private fun stopRingIfNeeded() {
        stopTicker()
        mediaPlayer?.let {
            try {
                if (it.isPlaying) it.stop()
            } catch (_: Throwable) {}
            try { it.release() } catch (_: Throwable) {}
        }
        mediaPlayer = null
    }

    private fun formatMs(ms: Long): String {
        val safe = ms.coerceAtLeast(0L)
        val totalSec = safe / 1000L
        val h = totalSec / 3600L
        val m = (totalSec % 3600L) / 60L
        val s = totalSec % 60L
        return if (h > 0) String.format("%02d:%02d:%02d", h, m, s) else String.format("%02d:%02d", m, s)
    }

    companion object {
        const val CHANNEL_ID = "fastertimer_alarm_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START_TIMER = "com.fastertimer.action.START_TIMER"
        const val ACTION_PAUSE_TIMER = "com.fastertimer.action.PAUSE_TIMER"
        const val ACTION_RESET_TIMER = "com.fastertimer.action.RESET_TIMER"
        const val ACTION_TIMER_FIRED = "com.fastertimer.action.TIMER_FIRED"
        const val ACTION_CONFIGURE_TIMER = "com.fastertimer.action.CONFIGURE_TIMER"
        const val ACTION_TIMER_FINISHED = "com.fastertimer.action.TIMER_FINISHED"

        const val EXTRA_APPARENT_MS = "extra_apparent_ms"
        const val EXTRA_REAL_MS = "extra_real_ms"
        const val EXTRA_PAUSED_REAL_ELAPSED_MS = "extra_paused_real_elapsed_ms"
        private const val DEFAULT_MS = 25 * 60 * 1000L

        fun startTimer(context: Context, apparentMs: Long, realMs: Long) {
            val intent = Intent(context, TimerForegroundService::class.java).apply {
                action = ACTION_START_TIMER
                putExtra(EXTRA_APPARENT_MS, apparentMs)
                putExtra(EXTRA_REAL_MS, realMs)
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun pauseTimer(context: Context) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, TimerForegroundService::class.java).apply { action = ACTION_PAUSE_TIMER }
            )
        }

        fun resetTimer(context: Context) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, TimerForegroundService::class.java).apply { action = ACTION_RESET_TIMER }
            )
        }

        fun configureTimer(context: Context, apparentMs: Long, realMs: Long) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, TimerForegroundService::class.java).apply {
                    action = ACTION_CONFIGURE_TIMER
                    putExtra(EXTRA_APPARENT_MS, apparentMs)
                    putExtra(EXTRA_REAL_MS, realMs)
                }
            )
        }

        fun timerFinished(context: Context) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, TimerForegroundService::class.java).apply { action = ACTION_TIMER_FIRED }
            )
        }
    }
}
