FasterTimer Android project with native alarm scheduling and an offline WebView UI.
